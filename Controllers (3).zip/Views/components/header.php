<nav>
    <div class="container">
         <div class="bar" onclick="opennav()"> <i class="fa fa-navicon"></i> </div>

         <h2 class="logo">Agent Dashboard </h2>

         <div class="create">    
                <a href="dashboard.php?logout=disconnect" class="login">Log out</a>

         </div>
    </div>
</nav>
