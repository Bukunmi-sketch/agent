<meta charset="utf-8">
         
         <meta name="viewport" content="width=device-width,
initial-scale=1">
         
         <meta http-equiv="X-UA-Compatible" content="ie=edge">
         <!--font awesome-->
         
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/
libs/font-awesome/4.7.0/css/font-awesome.min.css">
         
         <!--jquery-->
         
         <script src="https://code.Jquery.com/jquery-3.1.1.js"> </script>
         
         <!--spartan-->
         
         <link href="https://fonts.googleapis.com/css2?
family=Spartan:wght@300&display=swap" rel="stylesheet">
         
         <!--handlee-->
         
         <link href="https://fonts.googleapis.com/css?family=Handlee" 
rel="stylesheet">
         
         <!--rajdhani->
         <link href="https://fonts.googleapis.com/css?family=Rajdhani" 
rel="stylesheet ">
         
         <!--poppins-->
         <link href="https://fonts.googleapis.com/css?family=Poppins" 
rel="stylesheet">
         
         <!--lato-->
         <link href="https://fonts.googleapis.com/css?family=Lato&
display=swap" rel="stylesheet">
         
         
         <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
         <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" 
rel="stylesheet">
         
         
         <!--Google fonts-->
         <link rel="stylesheet" href="https://fonts.googleapis.com/icon?
family=Material+Icons">
         
         
         <link href="https://fonts.googleapis.com/css2?family=Open
+Sans:wght@300;400;600;700;800&family=Poppins:wght@100;200;300;
400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;
900&display=swap" rel="stylesheet">
         
         <!--ubuntu-->
         <link href="https://fonts.googleapis.com/css?family=Ubuntu" 
rel="stylesheet">
         <!--ubuntu-->
         <link href="https://fonts.googleapis.com/css?family=Ubuntu" 
rel="stylesheet">
         
         <!--Rametto-->
         <link href="https://fonts.googleapis.com/css?family=Rammetto
+One" rel="stylesheet">
         
         
         <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
         <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" 
rel="stylesheet">
        
        <!--
       <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" 
crossorigin>
        <link href="https://fonts.googleapis.com/css2?
family=Mukta:wght@600&display=swap" rel="stylesheet">
       
       -->
       
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" 
crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Cinzel&
family=Mukta:wght@600&display=swap" rel="stylesheet">
        